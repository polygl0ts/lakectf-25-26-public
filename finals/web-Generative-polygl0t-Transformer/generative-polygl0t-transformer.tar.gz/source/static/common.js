window.GPT_DEFAULT_LANG = {
    siteTitle: "GPT (Generative polygl0t Transformer)",
    brandSubtitle: "A human-powered helpdesk for the CTF finals.",
    bannerPrimary: "polygl0ts service notice:",
    bannerSecondary: "questions may be queued, answered badly, and later exposed to public judgement.",
    footerLine: "Fake GPT. Real queue. Dubious assistance.",
    inspiredByPrefix: "Inspired by",
    inspiredBy: "Inspired by \"your ai slop bores me\".",
    adminBadge: "admin",
    dashboardLink: "Dashboard",
    logoutButton: "Log out",
    registerLink: "Register",
    loginLink: "Log in",
    authTitle: "Register or log in",
    authBody: "Enter a username to create an account. The site generates a password once, then you use it to log in.",
    authEyebrow: "Access required",
    registerTab: "Create account",
    loginTab: "I already have a password",
    registerTitle: "Register",
    loginTitle: "Log in",
    usernameLabel: "Username",
    passwordLabel: "Password",
    usernamePlaceholder: "teamname",
    passwordPlaceholder: "paste your saved password",
    usernameRules: "Use 3-24 lowercase letters, digits, or underscores.",
    registerButton: "Generate password",
    loginButton: "Log in",
    registerSuccessTitle: "Registration complete",
    registerSuccessBody: "This password is only shown once. Save it before you log in.",
    registerResultTitle: "Account created",
    registerResultBody: "Here is your password. Save it now, because the site absolutely will not help you later.",
    generatedPasswordLabel: "Generated password",
    copyPasswordButton: "Copy password",
    continueToLogin: "Continue to login",
    copyPasswordSuccess: "Password copied.",
    copyPasswordFallback: "Copy it manually from the box above.",
    savePasswordWarning: "If you lose it, you will need a new account.",
    requestFailed: "The request failed.",
    missing_prompt: "Write a question first.",
    prompt_too_long: "That question is too long.",
    rate_limited: "Too many requests. Slow down and try again soon.",
    invalid_username: "Choose 3-24 lowercase letters, digits, or underscores.",
    username_taken: "That username already exists.",
    missing_username: "Enter your username.",
    missing_password: "Enter your password.",
    invalid_credentials: "That username or password is incorrect.",
    login_required: "Log in first.",
    admin_required: "Admin access is required.",
    claim_expired: "This claim expired.",
    homeEyebrow: "CTF finals helpdesk",
    homeTitle: "Stuck on a challenge?",
    homeSubtitle: "AI is banned for the finals, so this helpdesk is powered by actual polygl0ts members instead.",
    homeBody: "Ask for hints, exploit ideas, or a straight-up nudge in the right direction. Replies come from humans, so expect delays and the occasional comedic detour.",
    homePillOne: "humans, not AI",
    homePillTwo: "answered in the queue",
    homePillThree: "public after the finals",
    homeStepOneTitle: "Make an account",
    homeStepOneBody: "Registration asks only for a username and hands you one random password like a cursed internet relic.",
    homeStepTwoTitle: "Send a question",
    homeStepTwoBody: "Once logged in, throw your challenge pain into the queue and wait for a premium human response.",
    homeStepThreeTitle: "Pretend this is normal",
    homeStepThreeBody: "Enjoy the deeply serious fiction that this is a GPT replacement and not finals panic with extra steps.",
    publicWarningTitle: "Public after finals",
    cloudflareHintTitle: "Play on the remote",
    cloudflareHint: "This is a client-side challenge. Testing only on a local copy will miss the whole point — poke at the remote instance directly.",
    chatYou: "You",
    chatAssistant: "polygl0ts",
    abandonClaimHint: "Release the claim back to the queue so anyone can grab it.",
    composerEyebrow: "Ask a question",
    composerTitle: "Use the fake GPT replacement",
    historyEyebrow: "Saved chats",
    ctaEyebrow: "Get access",
    ctaTitle: "Acquire a completely normal user account",
    ctaBody: "Registration and login live on their own page now, because forcing both flows into one box was a terrible idea.",
    ctaMiniOneTitle: "Register",
    ctaMiniOneBody: "Enter only a username and the site creates the account instantly.",
    ctaMiniTwoTitle: "Save the password",
    ctaMiniTwoBody: "You see it once. After that, the site believes in consequences.",
    ctaMiniThreeTitle: "Ask better questions",
    ctaMiniThreeBody: "Then come back here and bother polygl0ts for challenge help.",
    authPageEyebrow: "Account portal",
    authPageTitle: "Rent a human-compatible account",
    authPageBody: "Registration is simple on purpose: enter a username, receive one random password, and guard it like it contains your finals dignity.",
    authPillOne: "username only",
    authPillTwo: "password shown once",
    authPillThree: "zero recovery budget",
    authStepOneTitle: "Type a username",
    authStepOneBody: "No email, no wizard, no inspirational productivity quotes.",
    authStepTwoTitle: "Receive your password",
    authStepTwoBody: "The site creates the account immediately and reveals the password exactly once.",
    authStepThreeTitle: "Log in and ask for help",
    authStepThreeBody: "Then you can bother polygl0ts like everyone else who misses GPT.",
    continueButton: "Continue",
    dashboardTitle: "Answer a question",
    dashboardEyebrow: "polygl0ts console",
    dashboardBody: "Pick the next question from the queue. You get 90 seconds per claim, extended while you keep typing.",
    dashStatusActive: "You are answering",
    dashStatusIdle: "Idle",
    dashStatusError: "Lost claim",
    queueCountLabel: "In queue",
    queueIdleHint: "Nothing waiting. Go have a snack.",
    queueHasItemsHint: "Players are waiting. Grab one.",
    queueTab: "Queue",
    answeredTab: "Answered",
    otherClaimedLabel: "Being answered by someone else",
    playerQuestionLabel: "Player question",
    promptPreviewLabel: "Prompt",
    answerPreviewLabel: "Answer",
    abandonClaim: "Put back in queue",
    submitAnswer: "Send answer",
    claimNext: "Take next question",
    draftLabel: "Your answer (supports bold / italic / headings)",
    noQueue: "Queue is empty.",
    noAnswered: "No answered questions yet.",
    noQueueToClaim: "Nothing to claim right now.",
    noActiveClaim: "Take a question before sending an answer.",
    emptyAnswer: "Write something before hitting send.",
    sending: "Sending..."
};

window.GPT = {
    allowedTags: ["b", "strong", "i", "em", "u", "p", "br", "h1", "h2", "h3", "h4", "ul", "ol", "li", "blockquote", "code"],
    t(key, fallback) {
        if (window.GPT_LANG && Object.prototype.hasOwnProperty.call(window.GPT_LANG, key)) {
            return window.GPT_LANG[key];
        }
        if (Object.prototype.hasOwnProperty.call(window.GPT_DEFAULT_LANG, key)) {
            return window.GPT_DEFAULT_LANG[key];
        }
        return fallback || key;
    },
    applyTranslations(root = document) {
        root.querySelectorAll("[data-i18n]").forEach((element) => {
            element.textContent = window.GPT.t(element.dataset.i18n, element.textContent);
        });
        root.querySelectorAll("[data-i18n-placeholder]").forEach((element) => {
            element.placeholder = window.GPT.t(element.dataset.i18nPlaceholder, element.placeholder || "");
        });
        root.querySelectorAll("[data-i18n-title]").forEach((element) => {
            element.title = window.GPT.t(element.dataset.i18nTitle, element.title || "");
        });
    },
    escapeHtml(value) {
        const div = document.createElement("div");
        div.textContent = value || "";
        return div.innerHTML;
    },
    renderRichText(value) {
        if (window.DOMPurify) {
            return window.DOMPurify.sanitize(value || "", {
                ALLOWED_TAGS: window.GPT.allowedTags
            });
        }
        return window.GPT.escapeHtml(value || "");
    },
    statusKey(status) {
        const mapping = {
            draft: "statusDraft",
            queued: "statusQueued",
            claimed: "statusTyping",
            answered: "statusAnswered",
            bot_pending: "statusBotPending",
            bot_processing: "statusBotPending",
            bot_failed: "statusBotFailed"
        };
        return mapping[status] || "statusLoading";
    },
    formatTime(secondsRemaining) {
        const safe = Math.max(0, secondsRemaining);
        const minutes = Math.floor(safe / 60);
        const seconds = safe % 60;
        return `${minutes}:${String(seconds).padStart(2, "0")}`;
    }
};

document.addEventListener("DOMContentLoaded", () => {
    window.GPT.applyTranslations();
});
