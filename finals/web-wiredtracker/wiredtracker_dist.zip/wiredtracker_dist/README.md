# LakeTracker

## Local setup
1. In `.env`, set `APP_URL` to `http://your-lan-ip:8080` (e.g. `APP_URL=http://192.168.1.30:8080`).
2. Run `docker compose up --build` to start the tracker and webplayer.
3. When the tracker is running, start the uploader with `docker compose -f compose-uploader.yaml up --build`.

The tracker will be available at `http://your-lan-ip:8080` and the webplayer at `http://your-lan-ip:8081`.
